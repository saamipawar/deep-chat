import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface MessageRequest {
  conversationId: string;
  message: string;
}

interface NLPAnalysis {
  sentiment: string;
  intent: string;
  confidence: number;
  entities: string[];
}

function analyzeMessage(text: string): NLPAnalysis {
  const lowerText = text.toLowerCase();
  
  const sentimentKeywords = {
    positive: ['good', 'great', 'excellent', 'happy', 'love', 'wonderful', 'fantastic', 'amazing', 'thanks', 'thank you', 'awesome', 'best', 'perfect'],
    negative: ['bad', 'terrible', 'awful', 'hate', 'worst', 'horrible', 'sad', 'angry', 'disappointed', 'frustrated', 'problem', 'issue', 'error', 'broken'],
  };

  const intentPatterns = [
    { intent: 'greeting', patterns: ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening'] },
    { intent: 'farewell', patterns: ['bye', 'goodbye', 'see you', 'farewell', 'take care'] },
    { intent: 'question', patterns: ['what', 'why', 'how', 'when', 'where', 'who', '?'] },
    { intent: 'help', patterns: ['help', 'assist', 'support', 'can you', 'could you'] },
    { intent: 'information', patterns: ['tell me', 'show me', 'explain', 'information', 'learn', 'know'] },
    { intent: 'complaint', patterns: ['problem', 'issue', 'not working', 'broken', 'error', 'wrong'] },
    { intent: 'thanks', patterns: ['thank', 'thanks', 'appreciate', 'grateful'] },
  ];

  let sentiment = 'neutral';
  let positiveScore = 0;
  let negativeScore = 0;

  sentimentKeywords.positive.forEach(keyword => {
    if (lowerText.includes(keyword)) positiveScore++;
  });

  sentimentKeywords.negative.forEach(keyword => {
    if (lowerText.includes(keyword)) negativeScore++;
  });

  if (positiveScore > negativeScore) sentiment = 'positive';
  else if (negativeScore > positiveScore) sentiment = 'negative';

  let intent = 'general';
  let maxMatches = 0;

  intentPatterns.forEach(pattern => {
    const matches = pattern.patterns.filter(p => lowerText.includes(p)).length;
    if (matches > maxMatches) {
      maxMatches = matches;
      intent = pattern.intent;
    }
  });

  const entities: string[] = [];
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
  const numberRegex = /\b\d+\b/g;
  const urlRegex = /https?:\/\/[^\s]+/g;

  const emails = text.match(emailRegex);
  const numbers = text.match(numberRegex);
  const urls = text.match(urlRegex);

  if (emails) entities.push(...emails.map(e => `email:${e}`));
  if (numbers) entities.push(...numbers.map(n => `number:${n}`));
  if (urls) entities.push(...urls.map(u => `url:${u}`));

  const confidence = Math.min(0.95, 0.6 + (maxMatches * 0.1) + (positiveScore + negativeScore) * 0.05);

  return { sentiment, intent, confidence, entities };
}

function generateResponse(message: string, analysis: NLPAnalysis): string {
  const { intent, sentiment } = analysis;

  const responses: Record<string, string[]> = {
    greeting: [
      "Hello! I'm an AI assistant powered by NLP and Deep Learning. How can I help you today?",
      "Hi there! I'm here to assist you. What can I do for you?",
      "Greetings! I'm your intelligent chatbot. What would you like to know?",
    ],
    farewell: [
      "Goodbye! Feel free to come back anytime you need assistance.",
      "Take care! I'm always here if you need help.",
      "See you later! Don't hesitate to return if you have more questions.",
    ],
    question: [
      "That's an interesting question! Based on my NLP analysis, I can help you explore this topic. Could you provide more details?",
      "I've processed your question using natural language understanding. Let me help you find the answer.",
      "Great question! My neural networks are analyzing the best way to assist you with this.",
    ],
    help: [
      "I'm here to help! I use advanced NLP techniques to understand your needs. What specific assistance do you require?",
      "Of course! My deep learning models are ready to assist you. Please tell me more about what you need.",
      "I'd be happy to help! I can understand and respond to various queries using natural language processing.",
    ],
    information: [
      "I can provide information on various topics using my trained neural networks. What would you like to learn about?",
      "My knowledge base is built on deep learning models. I'll do my best to share relevant information with you.",
      "Based on my NLP analysis, I can explain various concepts. What specific information are you looking for?",
    ],
    complaint: [
      "I understand you're experiencing an issue. My sentiment analysis detected this concern. Let me help you resolve it.",
      "I'm sorry to hear about the problem. I've analyzed your message and I'm here to assist in finding a solution.",
      "Thank you for bringing this to my attention. My NLP system has identified this as a priority concern.",
    ],
    thanks: [
      "You're very welcome! I'm glad my AI assistance was helpful.",
      "My pleasure! That's what I'm programmed for - to help and assist.",
      "Happy to help! Feel free to ask if you need anything else.",
    ],
    general: [
      "I've processed your message using NLP techniques. I understand you're saying: \"" + message + "\". How can I assist you further?",
      "My deep learning models have analyzed your input. I'm here to help with any questions or tasks you have.",
      "I'm an AI chatbot using natural language processing. I'm here to assist you in any way I can.",
    ],
  };

  const intentResponses = responses[intent] || responses.general;
  let response = intentResponses[Math.floor(Math.random() * intentResponses.length)];

  if (sentiment === 'positive') {
    const positiveAddons = [
      " I'm glad to sense the positive energy in your message!",
      " Your enthusiasm is wonderful!",
      " It's great to interact with someone so upbeat!",
    ];
    response += positiveAddons[Math.floor(Math.random() * positiveAddons.length)];
  } else if (sentiment === 'negative') {
    const supportiveAddons = [
      " I'm here to help make things better.",
      " Let's work together to improve the situation.",
      " I'm committed to assisting you.",
    ];
    response += supportiveAddons[Math.floor(Math.random() * supportiveAddons.length)];
  }

  if (analysis.entities.length > 0) {
    response += ` I also detected some key entities in your message that I'm taking into account.`;
  }

  return response;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const authHeader = req.headers.get('Authorization')!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const { conversationId, message }: MessageRequest = await req.json();

    const analysis = analyzeMessage(message);

    const { error: userMessageError } = await supabase
      .from('messages')
      .insert({
        conversation_id: conversationId,
        role: 'user',
        content: message,
        sentiment: analysis.sentiment,
        intent: analysis.intent,
        confidence: analysis.confidence,
      });

    if (userMessageError) throw userMessageError;

    const botResponse = generateResponse(message, analysis);

    const { data: botMessage, error: botMessageError } = await supabase
      .from('messages')
      .insert({
        conversation_id: conversationId,
        role: 'assistant',
        content: botResponse,
        sentiment: 'neutral',
        intent: 'response',
        confidence: 1.0,
      })
      .select()
      .single();

    if (botMessageError) throw botMessageError;

    await supabase
      .from('conversations')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', conversationId);

    return new Response(
      JSON.stringify({
        message: botMessage,
        analysis: {
          sentiment: analysis.sentiment,
          intent: analysis.intent,
          confidence: analysis.confidence,
          entities: analysis.entities,
        },
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});